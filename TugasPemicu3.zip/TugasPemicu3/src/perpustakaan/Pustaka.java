/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perpustakaan;

/**
 *
 * @author
 */

public abstract class Pustaka implements PunyaJudul, Stockable {
    
    private String judul;
    private int stok;
    private Penulis penulis;
    protected String tipe;
    
    public Pustaka(String judul, Penulis p)
    {
        this.judul = judul;
        this.penulis = p;
    }
    
    @Override
    public void setJudul(String judul)
    {
        this.judul = judul;
    }
    
    @Override
    public String getJudul()
    {
        return judul;
    }
    
    @Override
    public void tambahStok(int n){
       this.stok += n;
    }
    
    @Override
    public void ambilStok(int n)
    {
        if(isKosong())
        {
            return;
        }
        this.stok -= n;
    }
    
    @Override
    public int getStok()
    {
        return stok;
    }
    
    @Override
    public Boolean isKosong()
    {
        Boolean kosong = false;
        if(stok <= 0)
        {
            kosong = true;
            stok = 0;
        }
        return kosong;
    }
    
    public abstract void setPenulis(Penulis p);
        
    public void setPenulisx(Penulis p)
    {
        this.penulis = p;
    }
    
    public Penulis getPenulis()
    {
        return penulis;
    }
}
