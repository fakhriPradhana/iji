/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perpustakaan;

/**
 *
 * @author Maman
 */
public class TugasAkhir extends Pustaka {
   
    private String abstrak;
    
    public TugasAkhir(String judul, Penulis p, String abstrak)
    {
        super(judul, p);
        this.abstrak = abstrak;
    }
    
    public void setAbstrak(String abstrak) 
    {
        this.abstrak = abstrak;
    }
    public String getAbstrak()
    {
        return abstrak;
    }
    
    @Override
    public void setPenulis(Penulis p)
    {
        super.setPenulisx(p);
    }
    
    @Override
    public String toString()
    {
        // Blm tahu menahu
       return super.toString();
    }
    
    
}
