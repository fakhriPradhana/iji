/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perpustakaan;

/**
 *
 * @author Maman
 */
public class Katalog {
    
    private String genre;
    private Pustaka pustaka;
    
    public Katalog(String genre)
    {
        this.genre = genre;
    }
    
    public String getGenre()
    {
        return genre;
    }
    
    public void tambahPustaka(Pustaka pustaka)
    {
        this.pustaka = pustaka;
    }
    
    @Override
    public String toString()
    {
        return "";
    }
}
