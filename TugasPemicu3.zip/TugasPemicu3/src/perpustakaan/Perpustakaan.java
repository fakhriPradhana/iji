/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perpustakaan;
import java.util.Scanner;
/**
 *
 * @author Maman
 */
public class Perpustakaan {
    
    String nama;
    String alamat;
    Katalog katalog;
    static Scanner cin = new Scanner(System.in);
    
    public Perpustakaan(String nama, String alamat)
    {
        this.nama = nama;
        this.alamat = alamat;
    }
    
    public void tambahKatalog(String genre)
    {
        this.katalog = new Katalog(genre);
    }
    
    @Override
    public String toString()
    {
        return " " + nama + "\n" + " " + alamat;
    }

    public static void cetakMenuAwal()
    {
        System.out.println();
        System.out.println("PILIHAM MENU : ");
        System.out.println("1. Cari pustaka");
        System.out.println("2. Tambah pustaka");
        System.out.println("0. Keluar");
        System.out.print("Pilih : ");
    }
    
    public static int pilihMenu()
    {      
       return cin.nextInt();
    }
    public static void tambahPustaka()
    {
        int pil;
        do
        {
            System.out.println();
            System.out.println("PILIHAN TAMBAH PUSTAKA : ");
            System.out.println("1. Buku");
            System.out.println("2. Tugas Akhir");
            System.out.println("0. Kembali");
            System.out.println("Pilihan : ");
            pil = pilihMenu();
        
            if(pil == 1)
            {
                System.out.println("BUKU");
            }
            else if(pil == 2)
            {
                System.out.println("Tugas Akhir");
            }
        }
        while(pil != 0);
        
    }
    
    public static void cariPustaka()
    {
        int pil;
        do
        {
            System.out.println();
            System.out.println("PILIHAN CARI PUSTAKA : ");
            System.out.println("1. Buku");
            System.out.println("2. Tugas Akhir");
            System.out.println("0. Kembali");
            System.out.print("Pilih : ");
            pil = pilihMenu();  
            
            if(pil == 1)
            {
                System.out.println("BUKU");
            }
            else if(pil == 2)
            {
                System.out.println("TUGAS AKHIR");
            }
        }
        while(pil != 0);
        
        
               
    }
    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) {
        
        Perpustakaan perpus = new Perpustakaan("Perpustakaan Pusat Merapi Leg", "Jl. Jalannya Bersamamu jadiannya sama dia");
        int pil;
        do
        {
            System.out.println();
            System.out.println("+--------------------------------------+");
            System.out.println(" SELAMAT DATANG di " + "\n"+ perpus.toString());
            System.out.println("+--------------------------------------+");
            cetakMenuAwal();
            pil = pilihMenu(); 
            if (pil == 1)
            {
                cariPustaka();
            }
            else 
            {
                if(pil == 2)
                {
                    tambahPustaka();
                }
            }
            
        }
        while(pil != 0);
        
        
    }
    
}
