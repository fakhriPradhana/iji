// Teruntuk adeknya Hendra
package perpustakaan;

/**
 *
 * @author Maman
 */
public interface PunyaJudul {
    
    public void setJudul(String judul);
    public String getJudul();
    
}
