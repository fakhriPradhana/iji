/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perpustakaan;

/**
 *
 * @author Maman
 */
public class Buku extends Pustaka {
    
    private String penerbit;

    public Buku(String judul, Penulis p, String penerbit)
    {
        super(judul, p);
        this.penerbit = penerbit;
    }
    // SETTER
    public void setPenerbit(String penerbit) {
        this.penerbit = penerbit;
    }
    
    public String getPenerbit()
    {
        return penerbit;
    }
    
    @Override
    public void setPenulis(Penulis p)
    {
        super.setPenulisx(p);
    }
    
    @Override
    public String toString()
    {
        return super.toString();
    }
    
}
